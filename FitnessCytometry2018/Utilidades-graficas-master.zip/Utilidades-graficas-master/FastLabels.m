function FastLabels (xlab, ylab, titl)
% FastLabels (xlabel, ylabel, title)
xlabel(xlab)
ylabel(ylab)
title(titl)

end